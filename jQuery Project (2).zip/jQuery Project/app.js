let theMenDrop = $("#myMenDropdown");
let theMenBtn = $("#myMen");
$(document).ready(function () {
  $(theMenBtn).click(function () {
    $("#myMenDropdown").css({ "display": "block" });
    theMenBtn.toggleClass()
  });
  $("#myBtn").click(function () {
    if ($("#usersEmail").val() == "" || $("#usersEmail").val() == undefined) {
      // alert("working");
      $("#emailErr").html('Please fill in this field');
      $("#emailErr").css("color", "red")
    }
    if ($("#UsersPassword").val() == "" || $("#UsersPassword").val() == undefined) {
      $("#passwordErr").html('Please fill in this field');
      $("#passwordErr").css("color", "red");
    }
  });

  //     let nav_toggle = document.querySelector('.nav_toggle');
  // let nav_toggle_icon = document.querySelector('.nav_toggle ion-icon');
  // let nav_menu = document.querySelector('.nav_menu');

  // nav_toggle.addEventListener('click', () => {
  //   nav_menu.classList.toggle('active');
  //   nav_toggle_icon.setAttribute('name',
  //     nav_menu.classList.contains('active') ? 'close-outline' : 'menu-outline'
  //   );
  // });

  $("#createBTN").click(function () {
    // alert("working");
    if ($("#firstName").val() == "" || $("#firstName").val() == undefined) {
      $("#userFirstNameErr").html('Please fill in this field');
      $("#userFirstNameErr").css("color", "red");

    }
    if ($("#lastName").val() == "" || $("#lastName").val() == undefined) {
      $("#UserLastnameErr").html('Please fill in this field');
      $("#UserLastnameErr").css("color", "red");

    }
    if ($("#myEmail").val() == "" || $("#myEmail").val() == undefined) {
      $("#userEmailErr").html('Please fill in this field');
      $("#userEmailErr").css("color", "red");

    }
    if ($("#myPassword").val() == "" || $("#myPassword").val() == undefined) {
      $("#thePasswordErr").html('Please fill in this field');
      $("#thePasswordErr").css("color", "red");

    }
  });

  //images
  // $("#img-1").click(function () {
  //     $(this).addClass("imageBorder");
  // });

  // $("#img-2").click(function () {
  //     $(this).addClass("imageBorder");
  // });

  // $("#img-3").click(function () {
  //     $(this).addClass("imageBorder");
  // });

  // $("#img-4").click(function () {
  //     $(this).addClass("imageBorder");
  // });

  // $("#img-5").click(function () {
  //     $(this).addClass("imageBorder");
  // });

  //colors
  $("#color-1").click(function () {
    $(this).addClass("borderClass");
  });
  $("#color-2").click(function () {
    $(this).addClass("borderClass");
  });

  $("#color-3").click(function () {
    $(this).addClass("borderClass");
  });

  $("#color-4").click(function () {
    $(this).addClass("borderClass");
  });

  $("#color-5").click(function () {
    $(this).addClass("borderClass");
  });

  // DROP DOWN MENU
  $("#home").click(function () {
    $("#droppdown").slideToggle();
  });

  // let theP1 = $("#myP1");

  // $("#myP1").hover(function(){
  //     $("#myQuickAdd").css("display", "block");
  //     alert("working");
  // })
  const theFirstSize = $('#sizeOne');

  // Add a click event handler to the element

  theFirstSize.click(function (event) {
    if ($(event.target).is(theFirstSize)) {
      $(this).addClass("QuickOneBorder");
      $("#myCartBtn").css("display", "block");
      $("#selectSize").css("display", "none");
    }
  });
  // theFirstSize.click(function(){
  //   $("#myCartBtn").css("display", "block");
  // });

  // $("#myCartBtn").click(function(){
  //     // $(this).addClass("borderClass");
  //     $("#theWrapper").css("display", "block");
  // });

  // $("#myCartBtn").click(function(){
  //     $("#theWrapper").slideDown();
  //     $("#theWrapper").css("display", "block")
  //     alert("working")
  // });
  $("#cancel-btn").click(function () {
    $("#slide").hide();
  });


  //cart

  //   $.ajax({
  //   url: 'data.json',
  //   method: 'get',
  //   dataType: 'json',
  //   success: function(response) {
  //     localStorage.setItem('myCart',JSON.stringify(response));
  //     $.map(response.products, function(value, index) {
  //       let product = 
  //       `<div class="product-space">
  //         <div class="cart-image">
  //           <img src="./images/shoe-2.webp" alt="">
  //           <div class="cart-description">
  //             <p>${value.name}</p>
  //             <a href="#">HEKLA ORANGE</a>
  //             <select name="" id="">
  //               <option value="1">1</option>
  //               <option value="1">2</option>
  //               <option value="1">3</option>
  //               <option value="1">4</option>
  //               <option value="1">5</option>
  //               <option value="1">6</option>
  //               <option value="1">7</option>
  //               <option value="1">8</option>
  //               <option value="1">9</option>
  //               <option value="1">10</option>
  //             </select>
  //             <div class="cart-size_price">
  //               <h6>SIZE EU 46</h6>
  //               <p>&#8358 ${value.price}</p>
  //             </div>
  //           </div>
  //         </div>
  //       </div>
  //       <div class="my-checkout-parent">
  //         <div class="the-checkout-p">
  //           <div class="sub-total">
  //             <h4>SUBTOTAL</h4>
  //           </div>
  //           <div class="p-Price">
  //             <h4>&#8358 ${value.price}</h4>
  //           </div>
  //         </div>
  //         <div class="the-shipping">
  //           <div class="shipping">
  //             <h4>SHIPPING</h4>
  //           </div>
  //           <div class="calculated-checkout">
  //             <h4>calculated at checkout</h4>
  //           </div>
  //         </div>
  //         <div class="continue-clearCart">
  //           <div class="checkout-btn" id="checkoutBUTTON">
  //             <button>CHECKOUT</button>
  //           </div>
  //           <div class="continue-shopping">
  //             <a href="#">CONTINUE SHOPPING</a>
  //           </div>
  //           <div class="clear-cart">
  //             <a href="#">CLEAR CART</a>
  //           </div>
  //         </div>
  //         <div class="add-a-product">
  //           <h3>add a product from the rest of our collection</h3>
  //         </div>
  //       </div>`
  //     $(".checkout-section").append(product);
  //     });

  //   },
  //   error: function(err) {
  //     alert('server error');
  //   }

  // }); 


  // $("#cartDelete").click(function(){
  //   $(".checkout-section").remove();
  //   if($(".checkout-section").children().length ==  0){
  //     $(".View-cart").append('<p id="emptyCart">You do not have any items in your cart yet, <strong>continue shopping.</strong></p>')
  //   }
  // });
  // $("#cartDelete").click(function(){
  //   if($(".checkout-section").children().length ==  0){
  //       $(".checkout-section").append("You don't have any items in your cart yet, <strong>continue shopping.</strong>")
  //   }      
  // });
  //EmptyCart

  $.ajax({
    type: "GET",
    url: "http://159.65.21.42:9000/products",
    success: function (resp) {
      let myArr = [];
      $(resp).each(function (i, data) {
        if (data.category === "mahabiss") {
          myArr.push(data);
          console.log([data].length);
          let output = `
                        <div class="content">
                        <a href='singleP.html?id=${data._id}'}>
                            <img src='http://159.65.21.42:9000${data.image}' alt="Image" />
                            <h3>${data.name}</h3>
                            <p>${data.description}</p>
                            <h4>₦${data.price}</h4>
                        </a>
                        </div>
                        `;
          $("#theEntireProducts").append(output);
        }
      });
      // $("#theTotalProduct").html(myArr.length);
      //   console.log(myArr.length);
    },
    error: function (err) {
      console.log(err);
    },
  });


  //SINGLE PAGE
  let url = window.location.search;
  let urlParams = new URLSearchParams(url);
  let id = urlParams.get("id");
  $.ajax({
    type: "GET",
    url: `http://159.65.21.42:9000/product/${id}`,
    success: function (resp) {
      let outcome = `
                  <div class="productContent">
                      <img src="http://159.65.21.42:9000${resp.image}" alt="product"/>
                      <div>
                          <h2>${resp.name}</h2>
                          <p>${resp.description}</p>
                          <h3>₦${resp.price}</h3>
                          <button id="addToCart">Add To Cart</button>
                      </div>
                  </div>
              `;
      $(".mySingleP").append(outcome);


      $("#addToCart").click(function () {
        window.location.href = "view.html";
        let cartItem = {
          id: id,
          // image: myproduct.image,
          // name: myproduct.name,
          // price: myproduct.price,
          quantity: $("#Quantity").val()
        };
        let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
        cartItems.push(cartItem);
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
      });


        let myCart = JSON.parse(localStorage.getItem("cartItems")) || [];
        myCart.forEach(function(cartItem){
          $.ajax({
            type: "GET",
            url: `http://159.65.21.42:9000/product/${cartItem.id}`,
            success: function (myproduct) {
              let myresult = `<div class="product-space">
                      <div class="cart-image">
                        <img src="http://159.65.21.42:9000${myproduct.image}" alt="">
                        <div class="cart-description">
                          <p>${myproduct.name}</p>
                          <a href="#">HEKLA ORANGE</a>
                          <select name="Quantity" class= "quantity">
                            <option value="1">${myproduct.quantity}</option>
                            <option value="1">2</option>
                            <option value="1">3</option>
                            <option value="1">4</option>
                            <option value="1">5</option>
                            <option value="1">6</option>
                            <option value="1">7</option>
                            <option value="1">8</option>
                            <option value="1">9</option>
                            <option value="1">10</option>
                          </select>
                          <div class="cart-size_price">
                            <h6>SIZE EU 46</h6>
                            <p>&#8358 ${myproduct.price}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="my-checkout-parent">
                      <div class="the-checkout-p">
                        <div class="sub-total">
                          <h4>SUBTOTAL</h4>
                        </div>
                        <div class="p-Price">
                          <h4>&#8358 ${myproduct.price}</h4>
                        </div>
                      </div>
                      <div class="the-shipping">
                        <div class="shipping">
                          <h4>SHIPPING</h4>
                        </div>
                        <div class="calculated-checkout">
                          <h4>calculated at checkout</h4>
                        </div>
                      </div>
                      <div class="continue-clearCart">
                        <div class="checkout-btn" id="checkoutBUTTON">
                          <button>CHECKOUT</button>
                        </div>
                        <div class="continue-shopping">
                          <a href="#">CONTINUE SHOPPING</a>
                        </div>
                        <div class="clear-cart">
                          <a href="#">CLEAR CART</a>
                        </div>
                      </div>
                      <div class="add-a-product">
                        <h3> You can add a product from the rest of our collection</h3>
                      </div>
                    </div>`
  
              $(".checkout-section").append(myresult);
  
  
            },
          });
        });

        //DELETE PRODUCT 

        $("#cartDelete").click(function(){
          $(".checkout-section").remove();
        });
    },
  });


});